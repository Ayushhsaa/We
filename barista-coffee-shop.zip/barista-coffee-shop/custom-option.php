<?php

    $barista_coffee_shop_theme_css= "";

    /*--------------------------- Scroll To Top Positions -------------------*/

    $barista_coffee_shop_scroll_position = get_theme_mod( 'barista_coffee_shop_scroll_top_position','Right');
    if($barista_coffee_shop_scroll_position == 'Right'){
        $barista_coffee_shop_theme_css .='#button{';
            $barista_coffee_shop_theme_css .='right: 20px;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_scroll_position == 'Left'){
        $barista_coffee_shop_theme_css .='#button{';
            $barista_coffee_shop_theme_css .='left: 20px;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_scroll_position == 'Center'){
        $barista_coffee_shop_theme_css .='#button{';
            $barista_coffee_shop_theme_css .='right: 50%;left: 50%;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Slider Image Opacity -------------------*/

    $barista_coffee_shop_slider_img_opacity = get_theme_mod( 'barista_coffee_shop_slider_opacity_color','');
    if($barista_coffee_shop_slider_img_opacity == '0'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.1'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.1';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.2'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.2';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.3'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.3';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.4'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.4';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.5'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.5';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.6'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.6';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.7'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.7';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.8'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.8';
        $barista_coffee_shop_theme_css .='}';
        }else if($barista_coffee_shop_slider_img_opacity == '0.9'){
        $barista_coffee_shop_theme_css .='.slider-box img{';
            $barista_coffee_shop_theme_css .='opacity:0.9';
        $barista_coffee_shop_theme_css .='}';
        }

    /*---------------------------Slider Height ------------*/

    $barista_coffee_shop_slider_img_height = get_theme_mod('barista_coffee_shop_slider_img_height');
    if($barista_coffee_shop_slider_img_height != false){
        $barista_coffee_shop_theme_css .='#top-slider .owl-carousel .owl-item img{';
            $barista_coffee_shop_theme_css .='height: '.esc_attr($barista_coffee_shop_slider_img_height).';';
        $barista_coffee_shop_theme_css .='}';
    }

    /*---------------- Single post Settings ------------------*/

    $barista_coffee_shop_single_post_navigation_show_hide = get_theme_mod('barista_coffee_shop_single_post_navigation_show_hide',true);
    if($barista_coffee_shop_single_post_navigation_show_hide != true){
        $barista_coffee_shop_theme_css .='.nav-links{';
            $barista_coffee_shop_theme_css .='display: none;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Woocommerce Product Sale Positions -------------------*/

    $barista_coffee_shop_product_sale = get_theme_mod( 'barista_coffee_shop_woocommerce_product_sale','Right');
    if($barista_coffee_shop_product_sale == 'Right'){
        $barista_coffee_shop_theme_css .='.woocommerce ul.products li.product .onsale{';
            $barista_coffee_shop_theme_css .='left: auto; right: 15px;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_product_sale == 'Left'){
        $barista_coffee_shop_theme_css .='.woocommerce ul.products li.product .onsale{';
            $barista_coffee_shop_theme_css .='left: 15px; right: auto;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_product_sale == 'Center'){
        $barista_coffee_shop_theme_css .='.woocommerce ul.products li.product .onsale{';
            $barista_coffee_shop_theme_css .='right: 50%;left: 50%;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Woocommerce Related Products -------------------*/

    $barista_coffee_shop_woocommerce_related_product_show_hide = get_theme_mod('barista_coffee_shop_woocommerce_related_product_show_hide',true);
    if($barista_coffee_shop_woocommerce_related_product_show_hide != true){
        $barista_coffee_shop_theme_css .='.related.products{';
            $barista_coffee_shop_theme_css .='display: none;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Single Post Page Image Box Shadow -------------------*/

    $barista_coffee_shop_single_post_page_image_box_shadow = get_theme_mod('barista_coffee_shop_single_post_page_image_box_shadow',0);
    if($barista_coffee_shop_single_post_page_image_box_shadow != false){
        $barista_coffee_shop_theme_css .='.single-post .entry-header img{';
            $barista_coffee_shop_theme_css .='box-shadow: '.esc_attr($barista_coffee_shop_single_post_page_image_box_shadow).'px '.esc_attr($barista_coffee_shop_single_post_page_image_box_shadow).'px '.esc_attr($barista_coffee_shop_single_post_page_image_box_shadow).'px #cccccc;';
        $barista_coffee_shop_theme_css .='}';
    }

     /*--------------------------- Single Post Page Image Border Radius -------------------*/

    $barista_coffee_shop_single_post_page_image_border_radius = get_theme_mod('barista_coffee_shop_single_post_page_image_border_radius', 0);
    if($barista_coffee_shop_single_post_page_image_border_radius != false){
        $barista_coffee_shop_theme_css .='.single-post .entry-header img{';
            $barista_coffee_shop_theme_css .='border-radius: '.esc_attr($barista_coffee_shop_single_post_page_image_border_radius).'px;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Footer Background Image Position -------------------*/

    $barista_coffee_shop_footer_bg_image_position = get_theme_mod( 'barista_coffee_shop_footer_bg_image_position','scroll');
    if($barista_coffee_shop_footer_bg_image_position == 'fixed'){
        $barista_coffee_shop_theme_css .='#colophon{';
            $barista_coffee_shop_theme_css .='background-attachment: fixed !important; background-position: center !important;';
        $barista_coffee_shop_theme_css .='}';
    }elseif ($barista_coffee_shop_footer_bg_image_position == 'scroll'){
        $barista_coffee_shop_theme_css .='#colophon{';
            $barista_coffee_shop_theme_css .='background-attachment: scroll !important; background-position: center !important;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Footer Widget Heading Alignment -------------------*/

    $barista_coffee_shop_footer_widget_heading_alignment = get_theme_mod( 'barista_coffee_shop_footer_widget_heading_alignment','Left');
    if($barista_coffee_shop_footer_widget_heading_alignment == 'Left'){
        $barista_coffee_shop_theme_css .='#colophon h5, h5.footer-column-widget-title{';
        $barista_coffee_shop_theme_css .='text-align: left;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_footer_widget_heading_alignment == 'Center'){
        $barista_coffee_shop_theme_css .='#colophon h5, h5.footer-column-widget-title{';
            $barista_coffee_shop_theme_css .='text-align: center;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_footer_widget_heading_alignment == 'Right'){
        $barista_coffee_shop_theme_css .='#colophon h5, h5.footer-column-widget-title{';
            $barista_coffee_shop_theme_css .='text-align: right;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Footer background image -------------------*/

    $barista_coffee_shop_footer_bg_image = get_theme_mod('barista_coffee_shop_footer_bg_image');
    if($barista_coffee_shop_footer_bg_image != false){
        $barista_coffee_shop_theme_css .='#colophon{';
            $barista_coffee_shop_theme_css .='background: url('.esc_attr($barista_coffee_shop_footer_bg_image).');';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Copyright Background Color -------------------*/

    $barista_coffee_shop_copyright_background_color = get_theme_mod('barista_coffee_shop_copyright_background_color');
    if($barista_coffee_shop_copyright_background_color != false){
        $barista_coffee_shop_theme_css .='.footer_info{';
            $barista_coffee_shop_theme_css .='background-color: '.esc_attr($barista_coffee_shop_copyright_background_color).' !important;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Featured Image Border Radius -------------------*/

    $barista_coffee_shop_post_page_image_border_radius = get_theme_mod('barista_coffee_shop_post_page_image_border_radius', 0);
    if($barista_coffee_shop_post_page_image_border_radius != false){
        $barista_coffee_shop_theme_css .='.article-box img{';
            $barista_coffee_shop_theme_css .='border-radius: '.esc_attr($barista_coffee_shop_post_page_image_border_radius).'px;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Site Title And Tagline Color -------------------*/

    $barista_coffee_shop_logo_title_color = get_theme_mod('barista_coffee_shop_logo_title_color');
    if($barista_coffee_shop_logo_title_color != false){
        $barista_coffee_shop_theme_css .='p.site-title a, .navbar-brand a{';
            $barista_coffee_shop_theme_css .='color: '.esc_attr($barista_coffee_shop_logo_title_color).' !important;';
        $barista_coffee_shop_theme_css .='}';
    }

    $barista_coffee_shop_logo_tagline_color = get_theme_mod('barista_coffee_shop_logo_tagline_color');
    if($barista_coffee_shop_logo_tagline_color != false){
        $barista_coffee_shop_theme_css .='.logo p.site-description, .navbar-brand p{';
            $barista_coffee_shop_theme_css .='color: '.esc_attr($barista_coffee_shop_logo_tagline_color).'  !important;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Footer Widget Content Alignment -------------------*/

    $barista_coffee_shop_footer_widget_content_alignment = get_theme_mod( 'barista_coffee_shop_footer_widget_content_alignment','Left');
    if($barista_coffee_shop_footer_widget_content_alignment == 'Left'){
        $barista_coffee_shop_theme_css .='#colophon ul, #colophon p, .tagcloud, .widget{';
        $barista_coffee_shop_theme_css .='text-align: left;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_footer_widget_content_alignment == 'Center'){
        $barista_coffee_shop_theme_css .='#colophon ul, #colophon p, .tagcloud, .widget{';
            $barista_coffee_shop_theme_css .='text-align: center;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_footer_widget_content_alignment == 'Right'){
        $barista_coffee_shop_theme_css .='#colophon ul, #colophon p, .tagcloud, .widget{';
            $barista_coffee_shop_theme_css .='text-align: right;';
        $barista_coffee_shop_theme_css .='}';
    }

    /*--------------------------- Copyright Content Alignment -------------------*/

    $barista_coffee_shop_copyright_content_alignment = get_theme_mod( 'barista_coffee_shop_copyright_content_alignment','Right');
    if($barista_coffee_shop_copyright_content_alignment == 'Left'){
        $barista_coffee_shop_theme_css .='.footer-menu-left{';
        $barista_coffee_shop_theme_css .='text-align: left;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_copyright_content_alignment == 'Center'){
        $barista_coffee_shop_theme_css .='.footer-menu-left{';
            $barista_coffee_shop_theme_css .='text-align: center;';
        $barista_coffee_shop_theme_css .='}';
    }else if($barista_coffee_shop_copyright_content_alignment == 'Right'){
        $barista_coffee_shop_theme_css .='.footer-menu-left{';
            $barista_coffee_shop_theme_css .='text-align: right;';
        $barista_coffee_shop_theme_css .='}';
    }